#ifndef _ROS_SERVICE_SetPolygon_h
#define _ROS_SERVICE_SetPolygon_h
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "geometry_msgs/PolygonStamped.h"

namespace exploration_msgs
{

static const char SETPOLYGON[] = "exploration_msgs/SetPolygon";

  class SetPolygonRequest : public ros::Msg
  {
    public:
      typedef geometry_msgs::PolygonStamped _polygon_type;
      _polygon_type polygon;

    SetPolygonRequest():
      polygon()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      offset += this->polygon.serialize(outbuffer + offset);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      offset += this->polygon.deserialize(inbuffer + offset);
     return offset;
    }

    virtual const char * getType() override { return SETPOLYGON; };
    virtual const char * getMD5() override { return "e257093c51f646bb3fd81ee37f162324"; };

  };

  class SetPolygonResponse : public ros::Msg
  {
    public:

    SetPolygonResponse()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
     return offset;
    }

    virtual const char * getType() override { return SETPOLYGON; };
    virtual const char * getMD5() override { return "d41d8cd98f00b204e9800998ecf8427e"; };

  };

  class SetPolygon {
    public:
    typedef SetPolygonRequest Request;
    typedef SetPolygonResponse Response;
  };

}
#endif
