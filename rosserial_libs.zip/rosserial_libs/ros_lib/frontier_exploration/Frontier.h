#ifndef _ROS_frontier_exploration_Frontier_h
#define _ROS_frontier_exploration_Frontier_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "geometry_msgs/Point.h"

namespace frontier_exploration
{

  class Frontier : public ros::Msg
  {
    public:
      typedef uint32_t _size_type;
      _size_type size;
      typedef float _min_distance_type;
      _min_distance_type min_distance;
      typedef geometry_msgs::Point _travel_point_type;
      _travel_point_type travel_point;

    Frontier():
      size(0),
      min_distance(0),
      travel_point()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->size >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->size >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->size >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->size >> (8 * 3)) & 0xFF;
      offset += sizeof(this->size);
      offset += serializeAvrFloat64(outbuffer + offset, this->min_distance);
      offset += this->travel_point.serialize(outbuffer + offset);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      this->size =  ((uint32_t) (*(inbuffer + offset)));
      this->size |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->size |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->size |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->size);
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->min_distance));
      offset += this->travel_point.deserialize(inbuffer + offset);
     return offset;
    }

    virtual const char * getType() override { return "frontier_exploration/Frontier"; };
    virtual const char * getMD5() override { return "8e57df42619e81a60a4a5920d716e4b4"; };

  };

}
#endif
