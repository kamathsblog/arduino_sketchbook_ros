#ifndef _ROS_akros_msgs_Mode_h
#define _ROS_akros_msgs_Mode_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace akros_msgs
{

  class Mode : public ros::Msg
  {
    public:
      typedef bool _estop_type;
      _estop_type estop;
      typedef bool _rumble_type;
      _rumble_type rumble;
      typedef bool _auto_t_type;
      _auto_t_type auto_t;
      typedef bool _assist_type;
      _assist_type assist;
      typedef bool _play_t_type;
      _play_t_type play_t;
      typedef bool _store_type;
      _store_type store;

    Mode():
      estop(0),
      rumble(0),
      auto_t(0),
      assist(0),
      play_t(0),
      store(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_estop;
      u_estop.real = this->estop;
      *(outbuffer + offset + 0) = (u_estop.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->estop);
      union {
        bool real;
        uint8_t base;
      } u_rumble;
      u_rumble.real = this->rumble;
      *(outbuffer + offset + 0) = (u_rumble.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->rumble);
      union {
        bool real;
        uint8_t base;
      } u_auto_t;
      u_auto_t.real = this->auto_t;
      *(outbuffer + offset + 0) = (u_auto_t.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->auto_t);
      union {
        bool real;
        uint8_t base;
      } u_assist;
      u_assist.real = this->assist;
      *(outbuffer + offset + 0) = (u_assist.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->assist);
      union {
        bool real;
        uint8_t base;
      } u_play_t;
      u_play_t.real = this->play_t;
      *(outbuffer + offset + 0) = (u_play_t.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->play_t);
      union {
        bool real;
        uint8_t base;
      } u_store;
      u_store.real = this->store;
      *(outbuffer + offset + 0) = (u_store.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->store);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_estop;
      u_estop.base = 0;
      u_estop.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->estop = u_estop.real;
      offset += sizeof(this->estop);
      union {
        bool real;
        uint8_t base;
      } u_rumble;
      u_rumble.base = 0;
      u_rumble.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->rumble = u_rumble.real;
      offset += sizeof(this->rumble);
      union {
        bool real;
        uint8_t base;
      } u_auto_t;
      u_auto_t.base = 0;
      u_auto_t.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->auto_t = u_auto_t.real;
      offset += sizeof(this->auto_t);
      union {
        bool real;
        uint8_t base;
      } u_assist;
      u_assist.base = 0;
      u_assist.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->assist = u_assist.real;
      offset += sizeof(this->assist);
      union {
        bool real;
        uint8_t base;
      } u_play_t;
      u_play_t.base = 0;
      u_play_t.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->play_t = u_play_t.real;
      offset += sizeof(this->play_t);
      union {
        bool real;
        uint8_t base;
      } u_store;
      u_store.base = 0;
      u_store.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->store = u_store.real;
      offset += sizeof(this->store);
     return offset;
    }

    virtual const char * getType() override { return "akros_msgs/Mode"; };
    virtual const char * getMD5() override { return "6bfc96c7a79b4c3638e089cf94abe3bd"; };

  };

}
#endif
